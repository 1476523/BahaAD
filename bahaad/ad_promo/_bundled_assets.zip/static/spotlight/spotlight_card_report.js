// 番劇列表推廣卡片的檢舉功能（使用者 2026-09-19：播放器的推廣圖已經有檢舉表單，
// 列表卡片這個也該有）。一頁可能同時有好幾張推廣卡片（見 ad_promo/routes.py
// promo_card_slot() 每組插一張），懶惰建立、共用同一份表單浮層，點哪張卡片的
// 檢舉圖示（`.promo-card-report`）就把該卡片的 campaign_id 帶進去——跟
// spotlight_player.js 的檢舉表單同一套分類選項／同一個 `/anime/spotlight_report`
// 端點，差別只在這裡沒有 `sn`（不屬於任何一集）。
//
// 這個檔案跟整個 `bahaad/ad_promo/` 一樣刻意不進公開 repo，靠 base.html
// `{% include "ad_promo/_card_script.html" ignore missing %}` 選擇性載入——缺這個
// 檔案時 `.promo-card-report` 按鈕本來就不會被渲染出來（`ad_promo/_card.html`
// 也一起被排除），不會有殘留的無反應按鈕。
(function () {
  "use strict";

  var modal = null;
  var categorySel, detailInput, statusEl, submitBtn, cancelBtn;
  var activeCampaignId = null;

  function buildModal() {
    if (modal) return;
    modal = document.createElement("div");
    modal.className = "promo-card-report-modal";
    modal.hidden = true;
    modal.innerHTML =
      '<div class="promo-card-report-box">' +
      "<h3>檢舉這則推廣內容</h3>" +
      '<label><span>問題類型</span><select class="promo-card-report-category">' +
      '<option value="misleading">誤導或詐騙內容</option>' +
      '<option value="inappropriate">不當或攻擊性內容</option>' +
      '<option value="malware">疑似惡意連結／釣魚</option>' +
      '<option value="too_frequent">出現太頻繁</option>' +
      '<option value="irrelevant">與我無關／不感興趣</option>' +
      '<option value="broken">畫面跑版或連結失效</option>' +
      '<option value="other">其他</option>' +
      "</select></label>" +
      '<label><span>詳細說明（選填）</span>' +
      '<textarea class="promo-card-report-detail" maxlength="500" rows="3" placeholder="想補充的細節……"></textarea></label>' +
      '<p class="promo-card-report-status" hidden></p>' +
      '<div class="promo-card-report-actions">' +
      '<button type="button" class="btn-neutral promo-card-report-cancel">取消</button>' +
      '<button type="button" class="btn-accent promo-card-report-submit">送出檢舉</button>' +
      "</div></div>";
    document.body.appendChild(modal);
    categorySel = modal.querySelector(".promo-card-report-category");
    detailInput = modal.querySelector(".promo-card-report-detail");
    statusEl = modal.querySelector(".promo-card-report-status");
    submitBtn = modal.querySelector(".promo-card-report-submit");
    cancelBtn = modal.querySelector(".promo-card-report-cancel");
    modal.addEventListener("click", function (e) {
      if (e.target === modal) closeModal();
    });
    cancelBtn.addEventListener("click", closeModal);
    submitBtn.addEventListener("click", submitReport);
  }

  function openModal(campaignId) {
    buildModal();
    activeCampaignId = campaignId;
    detailInput.value = "";
    categorySel.value = "other";
    statusEl.hidden = true;
    statusEl.textContent = "";
    submitBtn.disabled = false;
    modal.hidden = false;
  }

  function closeModal() {
    if (modal) modal.hidden = true;
  }

  function submitReport() {
    submitBtn.disabled = true;
    statusEl.hidden = false;
    statusEl.textContent = "送出中……";
    fetch("/anime/spotlight_report", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        category: categorySel.value,
        detail: detailInput.value.slice(0, 500),
        sn: null,
        campaign_id: activeCampaignId,
      }),
    })
      .then(function (r) { return r.ok; })
      .catch(function () { return false; })
      .then(function (ok) {
        submitBtn.disabled = false;
        statusEl.textContent = ok ? "已送出，謝謝回報。" : "送出失敗，請稍後再試。";
        if (ok) { setTimeout(closeModal, 1200); }
      });
  }

  document.addEventListener("click", function (e) {
    var btn = e.target.closest ? e.target.closest(".promo-card-report") : null;
    if (btn) { openModal(btn.getAttribute("data-campaign-id") || null); }
  });
})();
