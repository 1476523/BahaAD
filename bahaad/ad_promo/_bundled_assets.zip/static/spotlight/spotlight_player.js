// 播放開始後第 1～10 秒投放推廣圖（使用者 2026-09-17）。只在遠端／公開模式播放時
// 出現（本機自己看不用放給自己看）。固定播放前頭反而容易被預期、被跳過，改成播放
// 「這次」開始後隨機 1～10 秒（相對時間，接續播放記憶點也一樣算從那個時間點起算）
// 才插入，比較不像制式的前導廣告。`promoGen` 是這次排程的世代編號——換下一集／
// 使用者中途操作導致重新排程時，舊的 timeupdate 監聽器／setTimeout 用世代編號比對
// 就知道自己已經過期，不會在切集之後才突然把新影片暫停或跳出舊的推廣圖。
//
// 使用者 2026-09-17 回報：「快轉」按不按得掉？——不會：顯示滿 10 秒才出現「推廣
// 內容」／「關閉廣告」是用真實時間的 setTimeout，不是看 video.currentTime 走到
// 哪，「« 10 秒」／「10 秒 »」只會動 currentTime，對這個計時完全沒影響。但原本
// 「上一話」／「下一話」／✕ 關閉會直接呼叫 load()/close()、把還在顯示中的推廣圖
// 跳過，episode_picker.js 補上 isActive() 檔下來，廣告顯示期間（使用者按下
// 「關閉廣告」之前）這三個按鈕都不會生效——使用者 2026-09-17 定案改成不自動消失，
// 要使用者自己按「關閉廣告」才收起，滿 10 秒才讓「推廣內容」／「關閉廣告」這兩顆
// 鈕出現（不是一開始就顯示）。檢舉圖示（左上角、紅色）不受 10 秒限制，廣告一顯示
// 就在，直到關閉廣告才跟著收起。
//
// 使用者 2026-09-18：這個檔案跟整個 `bahaad/ad_promo/` 一樣刻意不進公開 repo，只隨
// 編譯好的 exe 散布。episode_picker.js 定義了 `window.BahaAdPromo` 的預設 no-op
// 物件，這裡（如果有載入）直接整個覆蓋掉，提供真正的實作；`init()` 拿
// episode_picker.js 傳來的 video／overlay／closeBtn／remote／refresh／setActState
// 參考，`isActive()`／`onLoad(sn)`／`onClose()` 是 episode_picker.js 在
// sibling()／load()／close() 呼叫的掛勾。
//
// 使用者 2026-09-19：內容改抽動態廣告活動（見 anime_detail.html 對應的
// `ad_promo/_player_overlay.html`）——標題／連結／媒體類型／媒體網址渲染這頁當下
// 就定好，放在 overlay 的 `data-*` 屬性上，這裡只在真的要顯示的那一刻才把 `src`
// 補進對應的 `<img>`／`<video>` 元素（避免還沒觸發顯示就先預先下載一段用不到的
// 影片流量）。
//
// 使用者 2026-09-20：這個檔案（跟整個 static/spotlight/ 資料夾）從 `ad_promo` 改名
// `spotlight`——回報顯示異常，重整幾次都一樣，查出是本機廣告封鎖軟體（AdGuard
// 等）依網址關鍵字 `ad_promo`／`promo` 直接擋掉請求（伺服器端直接打 API 驗證過，
// 回應完全正常），跟載入時機無關。內部 Python 套件名稱 `bahaad.ad_promo` 不受
// 影響（不會出現在網址列）。
(function () {
  "use strict";

  var video, overlay, closeBtn, remote, refresh, setActState;
  var promoEl, promoActionsEl, promoVisitBtn, promoCloseBtn, promoReportBtn, promoReportForm;
  var promoReportCategory, promoReportDetail, promoReportStatus, promoReportCancelBtn, promoReportSubmitBtn;
  var mediaImgEl, mediaVideoEl, mediaFallbackEl;
  var mediaType = "image";
  var mediaUrl = "";
  var linkUrl = "https://github.com/1476523/BahaAD";
  var campaignId = "";
  var mediaLoaded = false;
  var mediaFailed = false; // 使用者 2026-09-20：素材被本機廣告封鎖軟體擋掉時設 true，
                            // 藏起「關閉廣告」按鈕，不能讓封鎖廣告變成免費的關閉鍵。
  var PROMO_ACTIONS_DELAY_MS = 10000;
  var promoGen = 0;
  var promoListener = null;
  var currentSn = null;
  var bound = false;

  function promoActive() {
    return !!(promoEl && !promoEl.hidden);
  }

  function stopMediaPlayback() {
    if (mediaVideoEl) { mediaVideoEl.pause(); mediaVideoEl.hidden = true; }
    if (mediaImgEl) mediaImgEl.hidden = true;
  }

  function dismissPromo() {
    if (!promoActive()) return;
    promoGen += 1; // 作廢還沒到的「10 秒後顯示按鈕」計時
    promoEl.hidden = true;
    if (promoActionsEl) promoActionsEl.hidden = true;
    if (promoReportForm) promoReportForm.hidden = true;
    if (closeBtn) closeBtn.disabled = false;
    stopMediaPlayback();
    if (refresh) refresh(); // 依目前已下載清單重新算「上一話」／「下一話」該不該可按
    video.play().catch(function () {});
  }

  function onMediaError() {
    mediaFailed = true;
    if (mediaFallbackEl) mediaFallbackEl.classList.add("is-blocked");
    updateCloseButtonVisibility();
  }

  function updateCloseButtonVisibility() {
    // 素材載入失敗（本機廣告封鎖軟體擋掉）就藏起「關閉廣告」——只剩「推廣內容」
    // 這個出口（點了算使用者自己選擇要不要去看），使用者要嘛關掉封鎖軟體讓素材
    // 真的顯示出來才能按到「關閉廣告」，不能什麼都看不到就直接免費關掉。
    if (promoCloseBtn) promoCloseBtn.hidden = mediaFailed;
  }

  function showMedia() {
    // 延到真的要顯示的這一刻才補 src——沒觸發到廣告（大部分情況）就完全不會下載
    // 這段媒體，省流量。
    if (mediaLoaded) return;
    mediaLoaded = true;
    if (mediaType === "video" && mediaVideoEl) {
      mediaVideoEl.onerror = onMediaError;
      mediaVideoEl.src = mediaUrl;
      mediaVideoEl.hidden = false;
      mediaVideoEl.play().catch(function () {});
      if (mediaImgEl) mediaImgEl.hidden = true;
    } else if (mediaImgEl) {
      mediaImgEl.onerror = onMediaError;
      mediaImgEl.src = mediaUrl;
      mediaImgEl.hidden = false;
      if (mediaVideoEl) mediaVideoEl.hidden = true;
    }
  }

  function bindButtons() {
    if (bound) return;
    bound = true;
    if (promoVisitBtn) promoVisitBtn.addEventListener("click", function () {
      window.open(linkUrl, "_blank", "noopener");
      dismissPromo();
    });
    if (promoCloseBtn) promoCloseBtn.addEventListener("click", dismissPromo);
    if (promoReportBtn) promoReportBtn.addEventListener("click", function () {
      if (promoReportForm) {
        promoReportForm.hidden = false;
        if (promoReportStatus) { promoReportStatus.hidden = true; promoReportStatus.textContent = ""; }
      }
    });
    if (promoReportCancelBtn) promoReportCancelBtn.addEventListener("click", function () {
      if (promoReportForm) promoReportForm.hidden = true;
    });
    if (promoReportSubmitBtn) promoReportSubmitBtn.addEventListener("click", function () {
      if (!promoReportStatus) return;
      promoReportSubmitBtn.disabled = true;
      promoReportStatus.hidden = false;
      promoReportStatus.textContent = "送出中……";
      var payload = {
        category: promoReportCategory ? promoReportCategory.value : "other",
        detail: promoReportDetail ? promoReportDetail.value.slice(0, 500) : "",
        sn: currentSn || null,
        campaign_id: campaignId || null,
      };
      fetch("/anime/spotlight_report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
        .then(function (r) { return r.ok; })
        .catch(function () { return false; })
        .then(function (ok) {
          promoReportSubmitBtn.disabled = false;
          promoReportStatus.textContent = ok ? "已送出，謝謝回報。" : "送出失敗，請稍後再試。";
          if (ok) {
            setTimeout(function () {
              if (promoReportForm) promoReportForm.hidden = true;
            }, 1200);
          }
        });
    });
  }

  function maybeSchedulePromo(sn, skipSchedule) {
    currentSn = sn;
    if (promoListener) { video.removeEventListener("timeupdate", promoListener); promoListener = null; }
    if (promoEl) promoEl.hidden = true;
    if (promoActionsEl) promoActionsEl.hidden = true;
    if (promoReportForm) promoReportForm.hidden = true;
    promoGen += 1;
    // 使用者 2026-09-20：`skipSchedule`（來自 episode_picker.js 的 `{ ssaiActive: true }`）
    // ——這一集的廣告已經（盡力）嵌進 HLS 串流本身，這裡只做上面的重置（清掉舊的
    // 排程／畫面），不再另外排一次 JS 疊加的計時器，避免同一次播放看到兩次廣告。
    if (skipSchedule || !remote || !promoEl || !mediaUrl) return;
    var myGen = promoGen;
    var targetElapsedMs = (1 + Math.random() * 9) * 1000;
    // 用真實時間（performance.now()）算「播放開始後過了幾秒」，不是 video.currentTime
    // 的差值——使用者 2026-09-20 提醒：如果播放新集數當下就直接跳（快轉／拖曳進度條）
    // 到中後段，currentTime 的差值會瞬間超過門檻，緊接著下一個 timeupdate 就跳出廣告，
    // 不是預期中「播放開始後 1～10 秒」。改用真實經過時間之後，不管使用者怎麼跳，都是
    // 從真的按下播放那一刻起算滿 1～10 秒才出現，不會被跳轉時間軸繞過。
    var startedAt = null;
    function onTimeUpdate() {
      if (myGen !== promoGen || video.paused) return;
      if (startedAt === null) startedAt = performance.now();
      if (performance.now() - startedAt < targetElapsedMs) return;
      video.removeEventListener("timeupdate", onTimeUpdate);
      promoListener = null;
      video.pause();
      promoEl.hidden = false;
      showMedia();
      if (setActState) { setActState("prev", false); setActState("next", false); }
      if (closeBtn) closeBtn.disabled = true;
      setTimeout(function () {
        if (myGen !== promoGen) return; // 這段等待期間換集／使用者已經操作過，作廢
        if (promoActionsEl) promoActionsEl.hidden = false;
        updateCloseButtonVisibility(); // 滿 10 秒這一刻的載入狀態才是最終判斷
      }, PROMO_ACTIONS_DELAY_MS);
    }
    promoListener = onTimeUpdate;
    video.addEventListener("timeupdate", onTimeUpdate);
  }

  window.BahaAdPromo = {
    init: function (ctx) {
      video = ctx.video;
      overlay = ctx.overlay;
      closeBtn = ctx.closeBtn;
      remote = ctx.remote;
      refresh = ctx.refresh;
      setActState = ctx.setActState;
      promoEl = document.getElementById("player-promo-overlay");
      promoActionsEl = document.getElementById("player-promo-actions");
      promoVisitBtn = document.getElementById("player-promo-visit-btn");
      promoCloseBtn = document.getElementById("player-promo-close-btn");
      promoReportBtn = document.getElementById("player-promo-report-btn");
      promoReportForm = document.getElementById("player-promo-report-form");
      promoReportCategory = document.getElementById("player-promo-report-category");
      promoReportDetail = document.getElementById("player-promo-report-detail");
      promoReportStatus = document.getElementById("player-promo-report-status");
      promoReportCancelBtn = document.getElementById("player-promo-report-cancel");
      promoReportSubmitBtn = document.getElementById("player-promo-report-submit");
      mediaImgEl = document.getElementById("player-promo-media-img");
      mediaVideoEl = document.getElementById("player-promo-media-video");
      mediaFallbackEl = document.getElementById("player-promo-fallback");
      if (promoEl) {
        mediaType = promoEl.dataset.mediaType === "video" ? "video" : "image";
        mediaUrl = promoEl.dataset.mediaUrl || "";
        linkUrl = promoEl.dataset.link || linkUrl;
        campaignId = promoEl.dataset.campaignId || "";
      }
      bindButtons();
    },
    isActive: promoActive,
    onLoad: function (sn, opts) {
      mediaLoaded = false; // 換集重新排程——下次真的顯示時要重新補一次 src
      mediaFailed = false;
      if (mediaFallbackEl) mediaFallbackEl.classList.remove("is-blocked"); // 清掉上一集留下的狀態
      updateCloseButtonVisibility();
      maybeSchedulePromo(sn, !!(opts && opts.ssaiActive));
    },
    onClose: function () {
      if (promoListener) { video.removeEventListener("timeupdate", promoListener); promoListener = null; }
      promoGen += 1;
      if (promoEl) promoEl.hidden = true;
      stopMediaPlayback();
    },
  };
})();
